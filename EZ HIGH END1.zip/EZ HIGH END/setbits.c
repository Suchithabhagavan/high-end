//set bits logic

/*main()
{
	int a,count;
	printf("num:");
	scanf("%d",&a);
	while(a)
	{
		count++;
		a=a&(a-1);
	}
	printf("number of set bits:%d",count);
	
}
 //second logic
 
main()
{
	int a,count=0;
	printf("enter num:");
	scanf("%d",&a);
	while(a>0)
	{
		if(a&1)
		{
			count++;
		}
		a=a>>1;
	}
	printf("count:%d",count);
}

//smallest number greater than 'n' with exactly 1 bit difference in binary form.
#include<stdio.h>
void main()
{
	int a=14;
	printf("%d",a | a+1);
}
*/




