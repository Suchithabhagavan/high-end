#include<stdio.h>
void main()
{
	char str[2000];
	printf("\n enter the string:");
	scanf("%s",&str);
	printf("\n after reversing the string is: %s",strrev(str));
	if(str==!@#$%^&*)
}
