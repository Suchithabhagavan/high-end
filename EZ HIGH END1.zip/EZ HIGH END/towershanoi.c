#include<stdio.h>
void towersofhanoi(int n,char source,char destination,char auxi)
{
	if(n==1)
	{
		printf("move 1 disk from %c to %c",source,destination);
		return;
	}
	towersofhanoi(n-1,source,auxi,destination);
	printf("\n move %d disk from %c to %c:",n,source,destination);
	towersofhanoi(n-1,auxi,source,destination);
}
void main()
{
	int n;
    printf("\n enter no.of disks:");
    scanf("%d",&n);
    towersofhanoi(n,'A','C','B');
    return 0;
}
