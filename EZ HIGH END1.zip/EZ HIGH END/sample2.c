main()
{
	int a=14;
	printf("%d",a | a+1);
}
