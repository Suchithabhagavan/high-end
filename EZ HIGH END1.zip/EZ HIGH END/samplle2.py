def threeSum(nums):
    triplets = []
    for i in range(len(nums) - 2):
        for j in range(i + 1, len(nums) - 1):
            for k in range(j + 1, len(nums)):
                if nums[i] + nums[j] + nums[k] == 0:
                    triplet = [nums[i], nums[j], nums[k]]
                    triplet.sort()  
                    if triplet not in triplets:
                        triplets.append(triplet)
    return triplets
nums = list(map(int,input().split()))
result = threeSum(nums)
print(result) 
