#include<stdio.h>
int isPOwerOfTwo(int num)
{
    if(num<=0)
    {
	return 0;
    }
    return (num&(num-1))==0;
}
void main()
{
	int a;
	printf("num:");
	scanf("%d",&a);
    if(isPowerOfTwo(a))
    {
        printf("yes",a);
    }
    else
    {
        printf("no");
    }
}
