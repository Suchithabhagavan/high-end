#include <stdio.h>
#include<math.h>
int main()
{
  int i, first, end;
  printf ("Enter the first range:");
  scanf ("%d", &first);
  printf ("Enter the end range:");
  scanf ("%d", &end);
  printf ("perfect squares between %d and %d: \n", first, end);
   for(i=first;i<=end;i++)
	{
    	double sqr=sqrt(i);
   		if(sqr-floor(sqr)==0)
        printf("%d \n",i);
    }
  return 0;
}
