#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Function to reverse a string in-place
void reverseString(char *str, int start, int end) {
    while (start < end) {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end--;
    }
}

// Function to reverse a sentence without changing special characters
void reverseSentence(char *sentence) {
    int length = strlen(sentence);
    int start = 0;
    
    for (i = 0; i <= length; i++) {
        // Check if the current character is a word character (alphabet or digit)
        if (isalnum(sentence[i]) || sentence[i] == '_') {
            continue; // Skip word characters
        }
        
        // Reverse the word
        reverseString(sentence, start, i - 1);
        start = i + 1; // Move to the next word
    }
    
    // Reverse the entire sentence
    reverseString(sentence, 0, length - 1);
}

int main() {
    char sentence[] = "Hello, how is your family?!";
    
    printf("Original sentence: %s\n", sentence);
    
    reverseSentence(sentence);
    
    printf("Reversed sentence: %s\n", sentence);
    
    return 0;
}

