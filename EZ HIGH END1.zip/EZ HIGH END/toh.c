def toh(n,source,dest,auxi):
    if n==0:
        return
    toh(n-1,source,dest,auxi)
    print("disk",n,"moved from",source,"to",dest)
    toh(n-1,auxi,source,dest)
n=int(input())
source,auxi,dest=input().split()
toh(n,source,auxi,dest)