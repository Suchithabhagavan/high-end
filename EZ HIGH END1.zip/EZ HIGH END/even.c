#include<stdio.h>
void main()
{
	int n;
	printf("num:");
	scanf("%d",&n);
	if(n&1)
	printf("odd");
	else
	printf("even");
}
