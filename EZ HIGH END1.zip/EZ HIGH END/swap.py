"""def swap_numbers(a, b):
    a = a ^ b
    b = a ^ b
    a = a ^ b
    return a, b

# Example usage:
x = 5
y = 10
x, y = swap_numbers(x, y)
print("Swapped x:", x)
print("Swapped y:", y)"""

dnum=15
#int count=0;
binary_rep=bin(dnum)[2:]
#if binary_rep==1
#count++;
'''while(dnum)
{
    count++;
    dnum=dnum&(dnum-1)
}'''
print(binary_rep)
